import AssetsTable from "../components/assets/AssetsTable";
import React from 'react'

const Assets = () => {
  return (
<div>
      <h2 style={{ textAlign: 'center', marginTop: 20 }}>Assets Management Table</h2>
      <AssetsTable />
    </div>
      )
}

export default Assets



