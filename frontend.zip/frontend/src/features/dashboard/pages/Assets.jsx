const Assets = () => <h1>Asset Management Page</h1>;
export default Assets;
