const Home = () => <h1>Welcome to Home Page</h1>;
export default Home;
