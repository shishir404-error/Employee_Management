const assetsData = [
  {
    id: 1,
    timestamp: "2024-06-24 10:30",
    name: "Shishir Sharma",
    empId: "EMP001",
    designation: "Developer",
    aadhaarName: "Shishir Kumar",
    productNo: "PR12345",
    serialNo: "SN67890",
    modelNo: "MDL54321",
    phoneNo: "9876543210",
    imeiNo: "123456789012345",
    dateOfJoining: "2023-01-10",
    address: "Lucknow, UP",
    topImage: "url",
    middleImage: "url",
    bottomImage: "url",
    chargerImage: "url",
    phoneImage: "url"
  }
];
